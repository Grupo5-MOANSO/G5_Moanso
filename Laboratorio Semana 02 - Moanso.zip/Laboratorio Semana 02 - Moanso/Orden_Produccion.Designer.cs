﻿namespace Laboratorio_Semana_02___Moanso
{
    partial class Orden_Produccion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Orden_Produccion));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRuc = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRazSoc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRepresentante = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEmpresa = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBoxMonitor = new System.Windows.Forms.CheckBox();
            this.checkBoxMicro = new System.Windows.Forms.CheckBox();
            this.checkBoxNeblineros = new System.Windows.Forms.CheckBox();
            this.checkBoxExtra = new System.Windows.Forms.CheckBox();
            this.checkBoxCopiloto = new System.Windows.Forms.CheckBox();
            this.checkBox180 = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxModelos = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBoxMarcas = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.radioButtonTuristico = new System.Windows.Forms.RadioButton();
            this.radioButtonUrbano = new System.Windows.Forms.RadioButton();
            this.radioButtonInter = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxEmpresas = new System.Windows.Forms.ComboBox();
            this.dataGridViewOP = new System.Windows.Forms.DataGridView();
            this.treeViewEstructura = new System.Windows.Forms.TreeView();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.listBoxComentarios = new System.Windows.Forms.ListBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnRegistrar = new FontAwesome.Sharp.IconButton();
            this.btnGuardar = new FontAwesome.Sharp.IconButton();
            this.label17 = new System.Windows.Forms.Label();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOP)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtDireccion);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtTelefono);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btnGuardar);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtRuc);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtRazSoc);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtRepresentante);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtEmpresa);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1874, 194);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REGISTRO CLIENTE";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(810, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Dirección:";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccion.Location = new System.Drawing.Point(993, 143);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(216, 32);
            this.txtDireccion.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(58, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Teléfono:";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefono.Location = new System.Drawing.Point(256, 140);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(216, 32);
            this.txtTelefono.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1606, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 26);
            this.label5.TabIndex = 9;
            this.label5.Text = "GUARDAR";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(810, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "RUC:";
            // 
            // txtRuc
            // 
            this.txtRuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRuc.Location = new System.Drawing.Point(993, 90);
            this.txtRuc.Name = "txtRuc";
            this.txtRuc.Size = new System.Drawing.Size(216, 32);
            this.txtRuc.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(810, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Razón Social:";
            // 
            // txtRazSoc
            // 
            this.txtRazSoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRazSoc.Location = new System.Drawing.Point(993, 43);
            this.txtRazSoc.Name = "txtRazSoc";
            this.txtRazSoc.Size = new System.Drawing.Size(216, 32);
            this.txtRazSoc.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(58, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Representante:";
            // 
            // txtRepresentante
            // 
            this.txtRepresentante.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRepresentante.Location = new System.Drawing.Point(256, 90);
            this.txtRepresentante.Name = "txtRepresentante";
            this.txtRepresentante.Size = new System.Drawing.Size(216, 32);
            this.txtRepresentante.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Empresa:";
            // 
            // txtEmpresa
            // 
            this.txtEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmpresa.Location = new System.Drawing.Point(256, 43);
            this.txtEmpresa.Name = "txtEmpresa";
            this.txtEmpresa.Size = new System.Drawing.Size(216, 32);
            this.txtEmpresa.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBoxMonitor);
            this.groupBox2.Controls.Add(this.checkBoxMicro);
            this.groupBox2.Controls.Add(this.checkBoxNeblineros);
            this.groupBox2.Controls.Add(this.checkBoxExtra);
            this.groupBox2.Controls.Add(this.checkBoxCopiloto);
            this.groupBox2.Controls.Add(this.checkBox180);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.comboBoxModelos);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.comboBoxMarcas);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.radioButtonTuristico);
            this.groupBox2.Controls.Add(this.radioButtonUrbano);
            this.groupBox2.Controls.Add(this.radioButtonInter);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.comboBoxEmpresas);
            this.groupBox2.Location = new System.Drawing.Point(12, 212);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1874, 254);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ORDEN DE PRODUCCIÓN";
            // 
            // checkBoxMonitor
            // 
            this.checkBoxMonitor.AutoSize = true;
            this.checkBoxMonitor.Location = new System.Drawing.Point(1558, 214);
            this.checkBoxMonitor.Name = "checkBoxMonitor";
            this.checkBoxMonitor.Size = new System.Drawing.Size(105, 24);
            this.checkBoxMonitor.TabIndex = 29;
            this.checkBoxMonitor.Text = "Monitores";
            this.checkBoxMonitor.UseVisualStyleBackColor = true;
            // 
            // checkBoxMicro
            // 
            this.checkBoxMicro.AutoSize = true;
            this.checkBoxMicro.Location = new System.Drawing.Point(1284, 213);
            this.checkBoxMicro.Name = "checkBoxMicro";
            this.checkBoxMicro.Size = new System.Drawing.Size(166, 24);
            this.checkBoxMicro.TabIndex = 28;
            this.checkBoxMicro.Text = "Amplificdor y Micro";
            this.checkBoxMicro.UseVisualStyleBackColor = true;
            // 
            // checkBoxNeblineros
            // 
            this.checkBoxNeblineros.AutoSize = true;
            this.checkBoxNeblineros.Location = new System.Drawing.Point(1558, 160);
            this.checkBoxNeblineros.Name = "checkBoxNeblineros";
            this.checkBoxNeblineros.Size = new System.Drawing.Size(110, 24);
            this.checkBoxNeblineros.TabIndex = 27;
            this.checkBoxNeblineros.Text = "Neblineros";
            this.checkBoxNeblineros.UseVisualStyleBackColor = true;
            // 
            // checkBoxExtra
            // 
            this.checkBoxExtra.AutoSize = true;
            this.checkBoxExtra.Location = new System.Drawing.Point(1284, 160);
            this.checkBoxExtra.Name = "checkBoxExtra";
            this.checkBoxExtra.Size = new System.Drawing.Size(166, 24);
            this.checkBoxExtra.TabIndex = 26;
            this.checkBoxExtra.Text = "Asiento extra N°33";
            this.checkBoxExtra.UseVisualStyleBackColor = true;
            // 
            // checkBoxCopiloto
            // 
            this.checkBoxCopiloto.AutoSize = true;
            this.checkBoxCopiloto.Location = new System.Drawing.Point(1558, 103);
            this.checkBoxCopiloto.Name = "checkBoxCopiloto";
            this.checkBoxCopiloto.Size = new System.Drawing.Size(151, 24);
            this.checkBoxCopiloto.TabIndex = 25;
            this.checkBoxCopiloto.Text = "Asiento Copiloto";
            this.checkBoxCopiloto.UseVisualStyleBackColor = true;
            // 
            // checkBox180
            // 
            this.checkBox180.AutoSize = true;
            this.checkBox180.Location = new System.Drawing.Point(1284, 103);
            this.checkBox180.Name = "checkBox180";
            this.checkBox180.Size = new System.Drawing.Size(137, 24);
            this.checkBox180.TabIndex = 24;
            this.checkBox180.Text = "Asientos  180°";
            this.checkBox180.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1071, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 20);
            this.label12.TabIndex = 23;
            this.label12.Text = "Adicionales:";
            // 
            // comboBoxModelos
            // 
            this.comboBoxModelos.FormattingEnabled = true;
            this.comboBoxModelos.Location = new System.Drawing.Point(1351, 39);
            this.comboBoxModelos.Name = "comboBoxModelos";
            this.comboBoxModelos.Size = new System.Drawing.Size(358, 28);
            this.comboBoxModelos.TabIndex = 22;
            this.comboBoxModelos.SelectedIndexChanged += new System.EventHandler(this.comboBoxModelos_SelectedIndexChanged_1);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1071, 46);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(173, 20);
            this.label11.TabIndex = 21;
            this.label11.Text = "Modelo de Fabricación:";
            // 
            // comboBoxMarcas
            // 
            this.comboBoxMarcas.FormattingEnabled = true;
            this.comboBoxMarcas.Location = new System.Drawing.Point(256, 100);
            this.comboBoxMarcas.Name = "comboBoxMarcas";
            this.comboBoxMarcas.Size = new System.Drawing.Size(418, 28);
            this.comboBoxMarcas.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(58, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 20);
            this.label10.TabIndex = 19;
            this.label10.Text = "Marca:";
            // 
            // radioButtonTuristico
            // 
            this.radioButtonTuristico.AutoSize = true;
            this.radioButtonTuristico.Location = new System.Drawing.Point(257, 214);
            this.radioButtonTuristico.Name = "radioButtonTuristico";
            this.radioButtonTuristico.Size = new System.Drawing.Size(93, 24);
            this.radioButtonTuristico.TabIndex = 18;
            this.radioButtonTuristico.TabStop = true;
            this.radioButtonTuristico.Text = "Turístico";
            this.radioButtonTuristico.UseVisualStyleBackColor = true;
            // 
            // radioButtonUrbano
            // 
            this.radioButtonUrbano.AutoSize = true;
            this.radioButtonUrbano.Location = new System.Drawing.Point(587, 156);
            this.radioButtonUrbano.Name = "radioButtonUrbano";
            this.radioButtonUrbano.Size = new System.Drawing.Size(87, 24);
            this.radioButtonUrbano.TabIndex = 17;
            this.radioButtonUrbano.TabStop = true;
            this.radioButtonUrbano.Text = "Urbano";
            this.radioButtonUrbano.UseVisualStyleBackColor = true;
            // 
            // radioButtonInter
            // 
            this.radioButtonInter.AutoSize = true;
            this.radioButtonInter.Location = new System.Drawing.Point(256, 156);
            this.radioButtonInter.Name = "radioButtonInter";
            this.radioButtonInter.Size = new System.Drawing.Size(132, 24);
            this.radioButtonInter.TabIndex = 16;
            this.radioButtonInter.TabStop = true;
            this.radioButtonInter.Text = "Interprovincial";
            this.radioButtonInter.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(58, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(124, 20);
            this.label9.TabIndex = 15;
            this.label9.Text = "Tipo de Servicio:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(58, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Empresa:";
            // 
            // comboBoxEmpresas
            // 
            this.comboBoxEmpresas.FormattingEnabled = true;
            this.comboBoxEmpresas.Location = new System.Drawing.Point(256, 38);
            this.comboBoxEmpresas.Name = "comboBoxEmpresas";
            this.comboBoxEmpresas.Size = new System.Drawing.Size(418, 28);
            this.comboBoxEmpresas.TabIndex = 0;
            this.comboBoxEmpresas.SelectedIndexChanged += new System.EventHandler(this.comboBoxEmpresas_SelectedIndexChanged);
            // 
            // dataGridViewOP
            // 
            this.dataGridViewOP.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewOP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewOP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dataGridViewOP.Location = new System.Drawing.Point(12, 754);
            this.dataGridViewOP.Name = "dataGridViewOP";
            this.dataGridViewOP.RowHeadersWidth = 62;
            this.dataGridViewOP.RowTemplate.Height = 28;
            this.dataGridViewOP.Size = new System.Drawing.Size(1450, 233);
            this.dataGridViewOP.TabIndex = 2;
            // 
            // treeViewEstructura
            // 
            this.treeViewEstructura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeViewEstructura.Location = new System.Drawing.Point(12, 504);
            this.treeViewEstructura.Name = "treeViewEstructura";
            this.treeViewEstructura.Size = new System.Drawing.Size(744, 224);
            this.treeViewEstructura.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 731);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "DETALLES:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 481);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(257, 20);
            this.label14.TabIndex = 5;
            this.label14.Text = "ESTRUCTURA DE MATERIALES:";
            // 
            // listBoxComentarios
            // 
            this.listBoxComentarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxComentarios.FormattingEnabled = true;
            this.listBoxComentarios.ItemHeight = 32;
            this.listBoxComentarios.Location = new System.Drawing.Point(795, 504);
            this.listBoxComentarios.Name = "listBoxComentarios";
            this.listBoxComentarios.Size = new System.Drawing.Size(667, 228);
            this.listBoxComentarios.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(791, 481);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 20);
            this.label15.TabIndex = 7;
            this.label15.Text = "COMENTARIOS:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1523, 490);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(312, 26);
            this.label16.TabIndex = 15;
            this.label16.Text = "REGISTRAR EN EL SISTEMA";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.IconChar = FontAwesome.Sharp.IconChar.CloudUploadAlt;
            this.btnRegistrar.IconColor = System.Drawing.Color.SlateBlue;
            this.btnRegistrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnRegistrar.IconSize = 130;
            this.btnRegistrar.Location = new System.Drawing.Point(1570, 519);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(214, 150);
            this.btnRegistrar.TabIndex = 14;
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.IconChar = FontAwesome.Sharp.IconChar.CaretSquareUp;
            this.btnGuardar.IconColor = System.Drawing.Color.Green;
            this.btnGuardar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnGuardar.IconSize = 90;
            this.btnGuardar.Location = new System.Drawing.Point(1581, 76);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(172, 90);
            this.btnGuardar.TabIndex = 8;
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1630, 864);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 26);
            this.label17.TabIndex = 15;
            this.label17.Text = "LIMPIAR";
            // 
            // iconButton1
            // 
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.Recycle;
            this.iconButton1.IconColor = System.Drawing.Color.DarkRed;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 90;
            this.iconButton1.Location = new System.Drawing.Point(1593, 893);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(172, 94);
            this.iconButton1.TabIndex = 14;
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Nombre de Empresa";
            this.Column1.MinimumWidth = 8;
            this.Column1.Name = "Column1";
            this.Column1.Width = 270;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "RUC";
            this.Column2.MinimumWidth = 8;
            this.Column2.Name = "Column2";
            this.Column2.Width = 250;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Marca de Chasis";
            this.Column3.MinimumWidth = 8;
            this.Column3.Name = "Column3";
            this.Column3.Width = 200;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Tipo de Servicio";
            this.Column4.MinimumWidth = 8;
            this.Column4.Name = "Column4";
            this.Column4.Width = 220;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Adicionales";
            this.Column5.MinimumWidth = 8;
            this.Column5.Name = "Column5";
            this.Column5.Width = 445;
            // 
            // Orden_Produccion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.listBoxComentarios);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.treeViewEstructura);
            this.Controls.Add(this.dataGridViewOP);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Orden_Produccion";
            this.Text = "Orden_Produccion";
            this.Load += new System.EventHandler(this.Orden_Produccion_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOP)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRuc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRazSoc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRepresentante;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEmpresa;
        private FontAwesome.Sharp.IconButton btnGuardar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxEmpresas;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox checkBoxMonitor;
        private System.Windows.Forms.CheckBox checkBoxMicro;
        private System.Windows.Forms.CheckBox checkBoxNeblineros;
        private System.Windows.Forms.CheckBox checkBoxExtra;
        private System.Windows.Forms.CheckBox checkBoxCopiloto;
        private System.Windows.Forms.CheckBox checkBox180;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBoxModelos;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxMarcas;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButtonTuristico;
        private System.Windows.Forms.RadioButton radioButtonUrbano;
        private System.Windows.Forms.RadioButton radioButtonInter;
        private System.Windows.Forms.DataGridView dataGridViewOP;
        private System.Windows.Forms.TreeView treeViewEstructura;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox listBoxComentarios;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private FontAwesome.Sharp.IconButton btnRegistrar;
        private System.Windows.Forms.Label label17;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}